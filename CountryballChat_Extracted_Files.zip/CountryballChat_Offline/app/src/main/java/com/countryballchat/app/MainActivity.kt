package com.countryballchat.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Send
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Navy = Color(0xFF102A56)
private val Blue = Color(0xFF1677E8)
private val Pale = Color(0xFFF2F6FC)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { CountryballApp() }
    }
}

@Composable
fun CountryballApp() {
    var selectedChat by remember { mutableStateOf<String?>(null) }
    MaterialTheme(colorScheme = lightColorScheme(primary = Blue, secondary = Navy, background = Pale)) {
        Surface(Modifier.fillMaxSize(), color = Pale) {
            if (selectedChat == null) HomeScreen { selectedChat = it }
            else ChatScreen(selectedChat!!) { selectedChat = null }
        }
    }
}

data class ChatPreview(val title: String, val message: String, val icon: String, val time: String)

@Composable
fun HomeScreen(onOpenChat: (String) -> Unit) {
    val chats = listOf(
        ChatPreview("گروه کانتری‌بال‌ها", "به گروه خوش اومدی! 🌍", "🌐", "20:15"),
        ChatPreview("اتاق گفت‌وگوی دوستان", "سلام، چه خبر؟", "💬", "19:42"),
        ChatPreview("اعلانات", "به Countryball Chat خوش آمدی", "📢", "دیروز")
    )
    Column(Modifier.fillMaxSize()) {
        Column(Modifier.fillMaxWidth().background(Navy).padding(18.dp)) {
            Text("🌍 Countryball Chat", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(5.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("👑", fontSize = 18.sp)
                Spacer(Modifier.width(6.dp))
                Text("مالک | ستاریان", color = Color.White, fontWeight = FontWeight.Bold)
                Spacer(Modifier.width(8.dp))
                Text("مالک (نمایشی)", color = Color(0xFFFFD76A), fontSize = 11.sp)
            }
        }
        Text("گفت‌وگوها", Modifier.padding(start = 18.dp, top = 18.dp, bottom = 8.dp),
            fontSize = 20.sp, fontWeight = FontWeight.Bold, color = Navy)
        LazyColumn(Modifier.weight(1f)) {
            items(chats) { chat ->
                Row(
                    Modifier.fillMaxWidth().clickable { onOpenChat(chat.title) }
                        .padding(horizontal = 14.dp, vertical = 7.dp)
                        .background(Color.White, RoundedCornerShape(16.dp)).padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(Modifier.size(52.dp).background(Color(0xFFE3EEFF), CircleShape),
                        contentAlignment = Alignment.Center) { Text(chat.icon, fontSize = 25.sp) }
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text(chat.title, fontWeight = FontWeight.Bold, color = Navy)
                        Text(chat.message, color = Color.Gray, fontSize = 13.sp)
                    }
                    Text(chat.time, color = Color.Gray, fontSize = 11.sp)
                }
            }
        }
        Text("نسخه آفلاین آزمایشی ۰٫۲ — پیام‌ها فقط روی همین صفحه هستند",
            Modifier.fillMaxWidth().padding(12.dp), color = Color.Gray, textAlign = TextAlign.Center, fontSize = 11.sp)
    }
}

@Composable
fun ChatScreen(chatName: String, onBack: () -> Unit) {
    var draft by remember { mutableStateOf("") }
    var messages by remember { mutableStateOf(listOf("به Countryball Chat خوش آمدی! 🌍")) }
    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().background(Navy).padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) {
                Icon(Icons.Default.ArrowBack, contentDescription = "بازگشت", tint = Color.White)
            }
            Text(chatName, color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
        }
        LazyColumn(Modifier.weight(1f).fillMaxWidth().padding(12.dp)) {
            items(messages) { message ->
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Start) {
                    Text(message, Modifier.padding(vertical = 5.dp)
                        .background(Color.White, RoundedCornerShape(14.dp)).padding(12.dp))
                }
            }
        }
        Row(Modifier.fillMaxWidth().background(Color.White).padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(value = draft, onValueChange = { draft = it },
                modifier = Modifier.weight(1f), placeholder = { Text("پیام بنویس...") }, maxLines = 3)
            IconButton(onClick = {
                if (draft.isNotBlank()) {
                    messages = messages + draft.trim()
                    draft = ""
                }
            }) { Icon(Icons.Default.Send, contentDescription = "ارسال", tint = Blue) }
        }
    }
}
